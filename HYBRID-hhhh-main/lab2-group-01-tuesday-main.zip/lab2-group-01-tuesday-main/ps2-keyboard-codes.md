### PS/2 keyboard codes

| Key | Make code | Break code | Key | Make code | Break code |
|---|---|---|---|---|---|
| ` | 0E | F0 0E | \ | 5D | F0 5D |
| 1 | 16 | F0 16 | Q | 15 | F0 15 |
| 2 | 1E | F0 1E | W | 1D | F0 1D |
| 3 | 26 | F0 26 | E | 24 | F0 24 |
| 4 | 25 | F0 25 | R | 2D | F0 2D |
| 5 | 2E | F0 2E | T | 2C | F0 2C | 
| 6 | 36 | F0 36 | Y | 35 | F0 35 | 
| 7 | 3D | F0 3D | U | 3C | F0 3C |
| 8 | 3E | F0 3E | I | 43 | F0 43 |
| 9 | 46 | F0 46 | O | 44 | F0 44 |
| 0 | 45 | F0 45 | P | 4D | F0 4D |
| - | 4E | F0 4E | [ | 54 | F0 54 |
| + | 55 | F0 55 | ] | 5B | F0 5B |
| A | 1C | F0 1C | C | 21 | F0 21 |
| S | 1B | F0 1B | V | 2A | F0 2A |
| D | 23 | F0 23 | B | 32 | F0 32 |
| F | 2B | F0 2B | N | 31 | F0 31 |
| G | 34 | F0 34 | M | 3A | F0 3A |
| H | 33 | F0 33 | , | 41 | F0 41 |
| J | 3B | F0 3B | . | 49 | F0 49 |
| K | 42 | F0 42 | / | 4A | F0 4A |
| L | 4B | F0 4B | space | 29 | F0 29 |
| ; | 4C | F0 4C | enter | 5A | F0 5A |
| ' | 52 | F0 52 | left shift | 12 | F0 12 |
| Z | 1A | F0 1A | right shift | 59 | F0 59 | 
| X | 22 | F0 22| 
